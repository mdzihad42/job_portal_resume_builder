from django.apps import AppConfig


class JobResumeConfig(AppConfig):
    name = 'job_resume'
